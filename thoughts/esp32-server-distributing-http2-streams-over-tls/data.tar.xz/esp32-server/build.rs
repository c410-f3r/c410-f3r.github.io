fn main() {
  println!(
    "cargo:rustc-link-arg=-Wl,--error-handling-script={}",
    std::env::current_exe().unwrap().display()
  );
  println!("cargo:rustc-link-arg=-Tlinkall.x");
}
