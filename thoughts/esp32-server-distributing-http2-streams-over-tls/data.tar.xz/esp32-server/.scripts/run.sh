#!/usr/bin/env bash

set -euo pipefail

export WIFI_PW="";
export WIFI_SSID="";

cargo run --release --quiet