use crate::{misc::LeaseMut, rng::CryptoRng};

/// A random number generator that is only initialized with cryptographically secure entropy.
pub trait CryptoSeedableRng: Sized {
  /// Number or array used to construct instances
  type Seed: Clone + Default + LeaseMut<[u8]>;

  /// Creates a new instance based on the entropy provided by the `getrandom` dependency.
  #[cfg(feature = "getrandom")]
  #[inline]
  fn from_getrandom() -> crate::Result<Self> {
    let mut seed = Self::Seed::default();
    getrandom::fill(seed.lease_mut())?;
    Self::from_seed(seed)
  }

  /// Creates a new instance based on another crypto RNG.
  #[inline]
  fn from_crypto_rng<R>(rng: &mut R) -> crate::Result<Self>
  where
    R: CryptoRng,
  {
    let mut seed = Self::Seed::default();
    rng.fill_slice(seed.lease_mut());
    Self::from_seed(seed)
  }

  /// Creates a new instance based on the entropy provided by `std::random`.
  #[cfg(all(feature = "nightly", feature = "std"))]
  #[inline]
  fn from_std_random() -> crate::Result<Self> {
    use core::random::Rng as _;
    let mut seed = Self::Seed::default();
    std::random::SystemRng.fill_bytes(seed.lease_mut());
    Self::from_seed(seed)
  }

  /// Creates a new instance based on the provided seed.
  fn from_seed(seed: Self::Seed) -> crate::Result<Self>;
}
