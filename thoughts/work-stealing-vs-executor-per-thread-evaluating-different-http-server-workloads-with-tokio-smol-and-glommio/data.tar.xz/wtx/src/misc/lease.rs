/// Copy of [`core::borrow::Borrow`] used to workaround orphan rules.
pub trait Lease<T>
where
  T: ?Sized,
{
  /// Immutable borrow.
  fn lease(&self) -> &T;
}

impl<T, U> Lease<U> for &T
where
  T: Lease<U> + ?Sized,
  U: ?Sized,
{
  #[inline]
  fn lease(&self) -> &U {
    <T as Lease<U>>::lease(*self)
  }
}

impl<T, U> Lease<U> for &mut T
where
  T: Lease<U> + ?Sized,
  U: ?Sized,
{
  #[inline]
  fn lease(&self) -> &U {
    <T as Lease<U>>::lease(*self)
  }
}

/// Copy of [`core::borrow::BorrowMut`] used to workaround orphan rules.
pub trait LeaseMut<T>: Lease<T>
where
  T: ?Sized,
{
  /// Mutable borrow.
  fn lease_mut(&mut self) -> &mut T;
}

impl<T, U> LeaseMut<U> for &mut T
where
  T: LeaseMut<U> + ?Sized,
  U: ?Sized,
{
  #[inline]
  fn lease_mut(&mut self) -> &mut U {
    <T as LeaseMut<U>>::lease_mut(*self)
  }
}

impl Lease<[u8]> for () {
  #[inline]
  fn lease(&self) -> &[u8] {
    &[]
  }
}

#[cfg(feature = "std")]
impl Lease<[u8]> for std::io::IoSlice<'_> {
  #[inline]
  fn lease(&self) -> &[u8] {
    self
  }
}

#[cfg(feature = "std")]
impl Lease<[u8]> for std::io::IoSliceMut<'_> {
  #[inline]
  fn lease(&self) -> &[u8] {
    self
  }
}

#[cfg(feature = "std")]
impl LeaseMut<[u8]> for std::io::IoSliceMut<'_> {
  #[inline]
  fn lease_mut(&mut self) -> &mut [u8] {
    self
  }
}

impl LeaseMut<[u8]> for () {
  #[inline]
  fn lease_mut(&mut self) -> &mut [u8] {
    &mut []
  }
}

impl<T> Lease<T> for alloc::borrow::Cow<'_, T>
where
  T: alloc::borrow::ToOwned + ?Sized,
{
  #[inline]
  fn lease(&self) -> &T {
    self.as_ref()
  }
}

impl<T> Lease<Option<T>> for Option<T> {
  #[inline]
  fn lease(&self) -> &Option<T> {
    self
  }
}

impl<T> LeaseMut<Option<T>> for Option<T> {
  #[inline]
  fn lease_mut(&mut self) -> &mut Option<T> {
    self
  }
}

mod collections {
  use crate::misc::{Lease, LeaseMut};
  use alloc::vec::Vec;

  impl<T> Lease<[T]> for [T] {
    #[inline]
    fn lease(&self) -> &[T] {
      self
    }
  }

  impl<T, const N: usize> Lease<[T]> for (u8, [T; N]) {
    #[inline]
    fn lease(&self) -> &[T] {
      let len = u8::try_from(N).unwrap_or(self.0).min(self.0);
      self.1.get(..usize::from(len)).unwrap_or_default()
    }
  }

  impl<T, const N: usize> Lease<[T; N]> for [T; N] {
    #[inline]
    fn lease(&self) -> &[T; N] {
      self
    }
  }

  impl<T, const N: usize> Lease<[T]> for [T; N] {
    #[inline]
    fn lease(&self) -> &[T] {
      self
    }
  }

  impl<T> Lease<[T]> for Vec<T> {
    #[inline]
    fn lease(&self) -> &[T] {
      self
    }
  }

  impl<T> Lease<Vec<T>> for Vec<T> {
    #[inline]
    fn lease(&self) -> &Vec<T> {
      self
    }
  }

  impl<T> LeaseMut<[T]> for [T] {
    #[inline]
    fn lease_mut(&mut self) -> &mut [T] {
      self
    }
  }

  impl<T, const N: usize> LeaseMut<[T; N]> for [T; N] {
    #[inline]
    fn lease_mut(&mut self) -> &mut [T; N] {
      self
    }
  }

  impl<T, const N: usize> LeaseMut<[T]> for [T; N] {
    #[inline]
    fn lease_mut(&mut self) -> &mut [T] {
      self
    }
  }

  impl<T> LeaseMut<[T]> for Vec<T> {
    #[inline]
    fn lease_mut(&mut self) -> &mut [T] {
      self
    }
  }

  impl<T> LeaseMut<Vec<T>> for Vec<T> {
    #[inline]
    fn lease_mut(&mut self) -> &mut Vec<T> {
      self
    }
  }
}

mod primitives {
  use crate::misc::{Lease, LeaseMut};

  macro_rules! implement {
    ($($ty:ty)*) => {
      $(
        impl Lease<$ty> for $ty {
          #[inline]
          fn lease(&self) -> &$ty {
            self
          }
        }

        impl LeaseMut<$ty> for $ty {
          #[inline]
          fn lease_mut(&mut self) -> &mut $ty {
            self
          }
        }
      )*
    };
  }

  implement!(f32 f64 i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize);
}

#[cfg(feature = "crypto-ring")]
mod ring {
  use crate::misc::Lease;
  use ring::digest::Digest;

  impl Lease<[u8]> for Digest {
    #[inline]
    fn lease(&self) -> &[u8] {
      self.as_ref()
    }
  }
}

mod smart_pointers {
  use crate::{
    misc::{Lease, LeaseMut},
    sync::Arc,
  };
  use alloc::boxed::Box;

  impl<T> Lease<T> for Arc<T> {
    #[inline]
    fn lease(&self) -> &T {
      self
    }
  }

  impl<T> Lease<T> for Box<T> {
    #[inline]
    fn lease(&self) -> &T {
      self
    }
  }

  impl<T> LeaseMut<T> for Box<T> {
    #[inline]
    fn lease_mut(&mut self) -> &mut T {
      self
    }
  }
}

mod str {
  use crate::misc::{Lease, LeaseMut};
  use alloc::string::String;

  impl Lease<[u8]> for str {
    #[inline]
    fn lease(&self) -> &[u8] {
      self.as_bytes()
    }
  }

  impl Lease<str> for str {
    #[inline]
    fn lease(&self) -> &str {
      self
    }
  }

  impl Lease<[u8]> for String {
    #[inline]
    fn lease(&self) -> &[u8] {
      self.as_bytes()
    }
  }

  impl Lease<str> for String {
    #[inline]
    fn lease(&self) -> &str {
      self
    }
  }
  impl LeaseMut<str> for String {
    #[inline]
    fn lease_mut(&mut self) -> &mut str {
      self
    }
  }

  impl Lease<String> for String {
    #[inline]
    fn lease(&self) -> &String {
      self
    }
  }
  impl LeaseMut<String> for String {
    #[inline]
    fn lease_mut(&mut self) -> &mut String {
      self
    }
  }
}

#[cfg(feature = "tokio")]
mod tokio {
  use crate::misc::{Lease, LeaseMut};
  use tokio::sync::MutexGuard;

  impl<T> Lease<T> for MutexGuard<'_, T> {
    #[inline]
    fn lease(&self) -> &T {
      self
    }
  }

  impl<T> LeaseMut<T> for MutexGuard<'_, T> {
    #[inline]
    fn lease_mut(&mut self) -> &mut T {
      self
    }
  }
}
