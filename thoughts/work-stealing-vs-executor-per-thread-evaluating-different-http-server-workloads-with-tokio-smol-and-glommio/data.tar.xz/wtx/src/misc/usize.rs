#![expect(
  clippy::as_conversions,
  clippy::cast_possible_truncation,
  reason = "some platforms were removed to allow infallible casts"
)]

#[cfg(not(any(target_pointer_width = "32", target_pointer_width = "64")))]
compile_error!("`WTX` requires hardware with a pointer size of at least 32 bits");

use core::ops::{Deref, DerefMut};

/// An `usize` that can be infallibly converted from an `u32`, which effectively drops support
/// for 8-bit or 16-bit hardware.
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct Usize(usize);

impl Usize {
  pub(crate) const fn from_u16(from: u16) -> Self {
    Self(from as usize)
  }

  pub(crate) const fn from_u32(from: u32) -> Self {
    Self(from as usize)
  }

  #[cfg(target_pointer_width = "64")]
  pub(crate) const fn from_u64(from: u64) -> Self {
    Self(from as usize)
  }

  pub(crate) const fn from_usize(from: usize) -> Self {
    Self(from)
  }

  // * 64 bits
  //
  // u64::MAX        = 18446744073709551615
  // u64::MAX as f64 = 18446744073709552000
  //
  // * 32 bits
  //
  // Infallible operation
  #[expect(clippy::cast_precision_loss, reason = "see comments")]
  pub(crate) const fn into_f64(self) -> f64 {
    self.0 as f64
  }

  pub(crate) const fn into_u64(self) -> u64 {
    self.0 as u64
  }

  pub(crate) const fn into_usize(self) -> usize {
    self.0
  }
}

impl Deref for Usize {
  type Target = usize;

  #[inline]
  fn deref(&self) -> &Self::Target {
    &self.0
  }
}

impl DerefMut for Usize {
  #[inline]
  fn deref_mut(&mut self) -> &mut Self::Target {
    &mut self.0
  }
}

impl From<u8> for Usize {
  #[inline]
  fn from(from: u8) -> Self {
    Self(from.into())
  }
}

impl From<u16> for Usize {
  #[inline]
  fn from(from: u16) -> Self {
    Self(from.into())
  }
}

impl From<u32> for Usize {
  #[inline]
  fn from(from: u32) -> Self {
    Self::from_u32(from)
  }
}

#[cfg(target_pointer_width = "64")]
impl From<u64> for Usize {
  #[inline]
  fn from(from: u64) -> Self {
    Self::from_u64(from)
  }
}

impl From<usize> for Usize {
  #[inline]
  fn from(from: usize) -> Self {
    Self::from_usize(from)
  }
}

impl From<Usize> for f64 {
  #[inline]
  fn from(from: Usize) -> Self {
    from.into_f64()
  }
}

impl From<Usize> for u64 {
  #[inline]
  fn from(from: Usize) -> Self {
    from.into_u64()
  }
}

impl From<Usize> for u128 {
  #[inline]
  fn from(from: Usize) -> Self {
    u64::from(from).into()
  }
}

impl From<Usize> for usize {
  #[inline]
  fn from(from: Usize) -> Self {
    from.into_usize()
  }
}
