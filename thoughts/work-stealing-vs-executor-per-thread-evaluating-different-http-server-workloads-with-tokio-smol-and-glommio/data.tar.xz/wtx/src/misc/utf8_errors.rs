use crate::misc::PartialChar;

/// Extended error built upon [`StdUtf8Error`].
#[derive(Clone, Copy, Debug)]
pub enum ExtUtf8Error {
  /// More bytes are needed to validate the string.
  Incomplete(PartialChar),
  /// It is impossible to validate the string
  Invalid,
}

/// Basic string error that doesn't contain any information.
#[derive(Clone, Copy, Debug)]
pub struct BasicUtf8Error;

impl From<BasicUtf8Error> for crate::Error {
  #[inline]
  #[track_caller]
  fn from(_: BasicUtf8Error) -> Self {
    Self::InvalidUTF8
  }
}

/// Standard error that is similar to the error type of the standard library.
#[derive(Clone, Copy, Debug)]
pub struct StdUtf8Error {
  /// Error length
  pub error_len: Option<usize>,
  /// Starting index of mal-formatted bytes
  pub valid_up_to: usize,
}
