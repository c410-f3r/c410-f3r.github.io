use crate::{crypto::dummy_crypto_call, misc::DefaultArray};
use core::marker::PhantomData;

#[cfg(feature = "crypto-alr")]
mod aws_lc_rs;
pub(crate) mod global;
#[cfg(feature = "crypto-graviola")]
mod graviola;
#[cfg(feature = "crypto-ring")]
mod ring;
#[cfg(feature = "crypto-ruco")]
mod ruco;

/// HMAC-based Key Derivation Function
pub trait Hkdf: Sized {
  /// Output array
  type Digest;

  /// The HKDF-Extract operation from the RFC-5869
  fn extract(salt: Option<&[u8]>, ikm: &[u8]) -> (Self::Digest, Self);

  /// Creates a new instance from an already cryptographically strong pseudorandom key.
  fn from_prk(prk: &[u8]) -> crate::Result<Self>;

  /// Performs a one-shot HMAC
  fn compute<'data>(
    data: impl IntoIterator<Item = &'data [u8]>,
    key: &[u8],
  ) -> crate::Result<Self::Digest>;

  /// The HKDF-Expand operation from the RFC-5869
  fn expand(&self, info: &[u8], okm: &mut [u8]) -> crate::Result<()>;
}

/// Dummy [`Hkdf`] implementation used when no backend is enabled.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct HkdfDummy<D>(PhantomData<D>);

impl<D> Hkdf for HkdfDummy<D>
where
  D: DefaultArray,
{
  type Digest = D;

  #[inline]
  fn extract(_: Option<&[u8]>, _: &[u8]) -> (Self::Digest, Self) {
    (D::default_array(), Self(PhantomData))
  }

  #[inline]
  fn from_prk(_: &[u8]) -> crate::Result<Self> {
    Ok(Self(PhantomData))
  }

  #[inline]
  fn compute<'data>(
    _: impl IntoIterator<Item = &'data [u8]>,
    _: &[u8],
  ) -> crate::Result<Self::Digest> {
    dummy_crypto_call();
  }

  #[inline]
  fn expand(&self, _: &[u8], _: &mut [u8]) -> crate::Result<()> {
    dummy_crypto_call();
  }
}
