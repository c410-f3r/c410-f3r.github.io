use crate::{crypto::dummy_crypto_call, misc::DefaultArray};
use core::marker::PhantomData;

#[cfg(feature = "crypto-alr")]
mod aws_lc_rs;
pub(crate) mod global;
#[cfg(feature = "crypto-graviola")]
mod graviola;
#[cfg(feature = "crypto-ring")]
mod ring;
#[cfg(feature = "crypto-ruco")]
mod ruco;

/// Keyed-hash message authentication code.
pub trait Hmac: Sized {
  /// Fixed-size output
  type Digest: AsRef<[u8]>;

  /// Creates a new instance from the given secret key.
  fn from_key(key: &[u8]) -> crate::Result<Self>;

  /// Finalizes the computation and returns the resulting digest.
  fn finalize(self) -> Self::Digest;

  /// Feeds additional data into the MAC computation.
  fn update(&mut self, data: &[u8]);

  /// Finalizes the computation and verifies the result against the provided tag.
  fn verify(self, tag: &[u8]) -> crate::Result<()>;
}

/// Dummy [`Hmac`] implementation used when no backend is enabled.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct HmacDummy<D>(PhantomData<D>);

impl<D> Hmac for HmacDummy<D>
where
  D: AsRef<[u8]> + DefaultArray,
{
  type Digest = D;

  #[inline]
  fn from_key(_: &[u8]) -> crate::Result<Self> {
    Ok(Self(PhantomData))
  }

  #[inline]
  fn finalize(self) -> Self::Digest {
    dummy_crypto_call();
  }

  #[inline]
  fn update(&mut self, _: &[u8]) {}

  #[inline]
  fn verify(self, _: &[u8]) -> crate::Result<()> {
    dummy_crypto_call();
  }
}
