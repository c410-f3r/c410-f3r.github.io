use crate::{crypto::dummy_crypto_call, misc::DefaultArray};
use core::marker::PhantomData;

#[cfg(feature = "crypto-alr")]
mod aws_lc_rs;
pub(crate) mod global;
#[cfg(feature = "crypto-graviola")]
mod graviola;
pub(crate) mod hash_ty;
#[cfg(feature = "crypto-ring")]
mod ring;
#[cfg(feature = "crypto-ruco")]
mod ruco;

/// Maps data of arbitrary size into a fixed-size value.
pub trait Hash: Sized {
  /// Output array
  type Digest: AsRef<[u8]>;

  /// Computes the hash digest of the given `data` and writes the resulting
  /// fixed-size output into `buffer`.
  #[inline]
  fn digest<'data>(data: impl IntoIterator<Item = &'data [u8]>) -> Self::Digest {
    let mut ctx = Self::new();
    for elem in data {
      ctx.update(elem);
    }
    ctx.finalize()
  }

  /// Creates a new empty instance.
  fn new() -> Self;

  /// Finalizes the computation.
  fn finalize(self) -> Self::Digest;

  /// Feeds additional data.
  fn update(&mut self, data: &[u8]);
}

/// Dummy [`Hash`] implementation used when no backend is enabled.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct HashDummy<D>(PhantomData<D>);

impl<D> Hash for HashDummy<D>
where
  D: AsRef<[u8]> + DefaultArray,
{
  type Digest = D;

  #[inline]
  fn new() -> Self {
    HashDummy(PhantomData)
  }

  #[inline]
  fn finalize(self) -> Self::Digest {
    dummy_crypto_call();
  }

  #[inline]
  fn update(&mut self, _: &[u8]) {}
}
