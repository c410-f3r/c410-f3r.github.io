use crate::crypto::Hkdf;

type HkdfSha256Ty = cfg_select! {
  feature = "crypto-ring" => crate::crypto::HkdfSha256Ring,
  feature = "crypto-alr" => crate::crypto::HkdfSha256Alr,
  feature = "crypto-graviola" => crate::crypto::HkdfSha256Graviola,
  feature = "crypto-ruco" => crate::crypto::HkdfSha256Ruco,
  _ => crate::crypto::HkdfDummy::<[u8; 32]>
};
type HkdfSha384Ty = cfg_select! {
  feature = "crypto-ring" => crate::crypto::HkdfSha384Ring,
  feature = "crypto-alr" => crate::crypto::HkdfSha384Alr,
  feature = "crypto-graviola" => crate::crypto::HkdfSha384Graviola,
  feature = "crypto-ruco" => crate::crypto::HkdfSha384Ruco,
  _ => crate::crypto::HkdfDummy::<[u8; 48]>
};

/// A structure that delegates execution to the selected crypto backend.
#[derive(Debug)]
pub struct HkdfSha256Global(HkdfSha256Ty);

impl Hkdf for HkdfSha256Global {
  type Digest = <HkdfSha256Ty as Hkdf>::Digest;

  #[inline]
  fn extract(salt: Option<&[u8]>, ikm: &[u8]) -> (Self::Digest, Self) {
    let (digest, this) = HkdfSha256Ty::extract(salt, ikm);
    (digest, Self(this))
  }

  #[inline]
  fn from_prk(prk: &[u8]) -> crate::Result<Self> {
    Ok(Self(HkdfSha256Ty::from_prk(prk)?))
  }

  #[inline]
  fn compute<'data>(
    data: impl IntoIterator<Item = &'data [u8]>,
    key: &[u8],
  ) -> crate::Result<Self::Digest> {
    HkdfSha256Ty::compute(data, key)
  }

  #[inline]
  fn expand(&self, info: &[u8], okm: &mut [u8]) -> crate::Result<()> {
    self.0.expand(info, okm)
  }
}

/// A structure that delegates execution to the selected crypto backend.
#[derive(Debug)]
pub struct HkdfSha384Global(HkdfSha384Ty);

impl Hkdf for HkdfSha384Global {
  type Digest = <HkdfSha384Ty as Hkdf>::Digest;

  #[inline]
  fn extract(salt: Option<&[u8]>, ikm: &[u8]) -> (Self::Digest, Self) {
    let (digest, this) = HkdfSha384Ty::extract(salt, ikm);
    (digest, Self(this))
  }

  #[inline]
  fn from_prk(prk: &[u8]) -> crate::Result<Self> {
    Ok(Self(HkdfSha384Ty::from_prk(prk)?))
  }

  #[inline]
  fn compute<'data>(
    data: impl IntoIterator<Item = &'data [u8]>,
    key: &[u8],
  ) -> crate::Result<Self::Digest> {
    HkdfSha384Ty::compute(data, key)
  }

  #[inline]
  fn expand(&self, info: &[u8], okm: &mut [u8]) -> crate::Result<()> {
    self.0.expand(info, okm)
  }
}
