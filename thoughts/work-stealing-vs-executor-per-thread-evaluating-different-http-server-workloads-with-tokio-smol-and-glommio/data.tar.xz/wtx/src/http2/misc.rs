use crate::{
  _AFTER_CLOSE_TIMEOUT_MS,
  futures::Sleep,
  http::{HttpRecvParams, MsgBufferString, MsgDataMut as _, StatusCode, U31},
  http2::{
    Http2Data, Http2Error, Http2ErrorCode, Http2Inner, Http2RecvStatus, Http2SendStatus, Scorp,
    Sovrp, Windows,
    common_flags::CommonFlags,
    frame_init::{FrameInit, FrameInitTy},
    go_away_frame::GoAwayFrame,
    headers_frame::HeadersFrame,
    hpack_decoder::HpackDecoder,
    http2_data::Http2DataPartsMut,
    reset_stream_frame::ResetStreamFrame,
    stream_receiver::{StreamControlRecvParams, StreamOverallRecvParams},
    stream_state::StreamState,
  },
  misc::Usize,
  net::{BufStreamReader, ConnectionState, StreamReader, StreamWriter},
  sync::AtomicU8,
  tls::{TlsMode, TlsStreamWriter},
};
use core::{
  mem,
  sync::atomic::Ordering,
  task::{Context, Poll},
  time::Duration,
};

pub(crate) fn check_content_length(
  content_length: Option<usize>,
  msg_buffer: &MsgBufferString,
) -> crate::Result<()> {
  let Some(elem) = content_length else {
    return Ok(());
  };
  if msg_buffer.body.len() != elem {
    return Err(protocol_err(Http2Error::InvalidContentLength));
  }
  Ok(())
}

pub(crate) fn frame_reader_rslt(err: &mut Option<crate::Error>) -> crate::Result<()> {
  match err.take() {
    Some(elem) => Err(elem),
    None => Ok(()),
  }
}

pub(crate) fn connection_state(atomic_bool: &AtomicU8) -> ConnectionState {
  ConnectionState::from(atomic_bool.load(Ordering::Relaxed))
}

#[track_caller]
pub(crate) fn scrp_mut(
  scrp: &mut Scorp,
  stream_id: U31,
) -> crate::Result<&mut StreamControlRecvParams> {
  scrp
    .get_mut(&stream_id)
    .ok_or_else(|| protocol_err(Http2Error::UnknownControlStreamId(stream_id)))
}

#[track_caller]
pub(crate) fn sorp_mut(
  sorp: &mut Sovrp,
  stream_id: U31,
) -> crate::Result<&mut StreamOverallRecvParams> {
  sorp
    .get_mut(&stream_id)
    .ok_or_else(|| protocol_err(Http2Error::UnknownOverallStreamId(stream_id)))
}

/// * If the streams are in overall receiving mode, than `scrp` don't exist.
/// * Callers of this function are already in an active future, as such, it is not necessary to
///   awake them again.
pub(crate) fn manage_recurrent_receiving_of_overall_stream<EOS, const IS_CLIENT: bool>(
  cx: &mut Context<'_>,
  mut hdpm: Http2DataPartsMut<'_, IS_CLIENT>,
  is_conn_open: &AtomicU8,
  stream_id: U31,
  cb_eos: impl FnOnce(&mut Http2DataPartsMut<'_, IS_CLIENT>, StatusCode, StreamState, Windows) -> EOS,
) -> Poll<crate::Result<(Http2RecvStatus<EOS, ()>, MsgBufferString)>> {
  macro_rules! eos {
    ($hdpm:expr, $hrs:ident, $sorp:expr, $stream_id:expr) => {{
      let content_length = $sorp.content_length;
      let msg_buffer = mem::take(&mut $sorp.msg_buffer);
      let status_code = $sorp.status_code;
      let stream_state = $sorp.stream_state;
      let windows = $sorp.windows;
      drop($hdpm.hb.sorps.remove($stream_id));
      check_content_length(content_length, &msg_buffer)?;
      let eos = cb_eos(&mut $hdpm, status_code, stream_state, windows);
      Poll::Ready(Ok((Http2RecvStatus::$hrs(eos), msg_buffer)))
    }};
  }

  let sorp = sorp_mut(&mut hdpm.hb.sorps, stream_id)?;
  match (!connection_state(is_conn_open).is_closed(), sorp.is_stream_open) {
    (false, false | true) => {
      let msg_buffer = mem::take(&mut sorp.msg_buffer);
      drop(hdpm.hb.sorps.remove(&stream_id));
      frame_reader_rslt(hdpm.frame_reader_error)?;
      return Poll::Ready(Ok((Http2RecvStatus::ClosedConnection, msg_buffer)));
    }
    (true, false) => return eos!(hdpm, ClosedStream, sorp, &stream_id),
    (true, true) => {}
  }
  if sorp.stream_state.recv_eos() {
    return eos!(hdpm, Eos, sorp, &stream_id);
  }
  sorp.waker.clone_from(cx.waker());
  Poll::Pending
}

pub(crate) async fn manage_termination<SW, TM, const IS_CLIENT: bool, const IS_RECV: bool>(
  error_code: Http2ErrorCode,
  inner: &Http2Inner<SW, TM, IS_CLIENT>,
) where
  SW: StreamWriter,
  TM: TlsMode,
{
  async fn close<SW, TM, const IS_CLIENT: bool>(
    error_code: Http2ErrorCode,
    inner: &Http2Inner<SW, TM, IS_CLIENT>,
    last_stream_id: U31,
  ) where
    SW: StreamWriter,
    TM: TlsMode,
  {
    let mut lock = inner.wd.lock().await;
    do_send_go_away(error_code, last_stream_id, &mut *lock).await;
    lock.close_abruptly();
    wake_tasks(&mut *inner.hd.lock().await);
  }

  async fn do_send_go_away<SW, TM, const IS_CLIENT: bool>(
    error_code: Http2ErrorCode,
    last_stream_id: U31,
    stream_writer: &mut TlsStreamWriter<SW, TM, IS_CLIENT>,
  ) where
    SW: StreamWriter,
    TM: TlsMode,
  {
    let gaf = GoAwayFrame::new(error_code, last_stream_id);
    let _rslt = stream_writer.write_all(&gaf.bytes()).await;
  }

  fn wake_tasks<const IS_CLIENT: bool>(hd: &mut Http2Data<IS_CLIENT>) {
    let hdpm = hd.parts_mut();
    while let Some(elem) = hdpm.hb.initial_server_streams_local.pop_front() {
      elem.wake();
    }
    for (_, value) in hdpm.hb.scrps.drain() {
      value.waker.wake();
    }
    for (_, value) in hdpm.hb.sorps.drain() {
      value.waker.wake();
    }
  }

  if error_code.is_fatal() {
    if IS_RECV {
      inner.wd.lock().await.close_abruptly();
      wake_tasks(&mut *inner.hd.lock().await);
    } else {
      let last_stream_id = *inner.hd.lock().await.parts_mut().last_stream_id;
      close(error_code, inner, last_stream_id).await;
    }
    return;
  }
  inner.is_conn_open.store(ConnectionState::Draining.into(), Ordering::Relaxed);
  let last_stream_id = *inner.hd.lock().await.parts_mut().last_stream_id;
  do_send_go_away(error_code, last_stream_id, &mut *inner.wd.lock().await).await;
  wake_tasks(&mut *inner.hd.lock().await);
  let Ok(sleep) = Sleep::new(Duration::from_millis(_AFTER_CLOSE_TIMEOUT_MS)) else {
    close(Http2ErrorCode::ProtocolError, inner, last_stream_id).await;
    return;
  };
  let _sleep_rslt = sleep.await;
  close(Http2ErrorCode::ProtocolError, inner, last_stream_id).await;
}

#[expect(clippy::wildcard_enum_match_arm, reason = "too many variants")]
pub(crate) async fn process_higher_operation_err<SW, TM, const IS_CLIENT: bool>(
  err: &crate::Error,
  inner: &Http2Inner<SW, TM, IS_CLIENT>,
) where
  SW: StreamWriter,
  TM: TlsMode,
{
  match err {
    crate::Error::Http2ErrorGoAway(http2_error_code, _) => {
      manage_termination::<_, _, _, false>(*http2_error_code, inner).await;
    }
    crate::Error::Http2FlowControlError(_, stream_id) => {
      let _ = send_reset_stream(Http2ErrorCode::FlowControlError, inner, stream_id.into()).await;
    }
    _ => {
      // Triggers a very specific path where `manage_termination` does not reply a `GOAWAY`.
      manage_termination::<_, _, _, false>(Http2ErrorCode::ProtocolError, inner).await;
    }
  }
}

pub(crate) const fn protocol_err(error: Http2Error) -> crate::Error {
  crate::Error::Http2ErrorGoAway(Http2ErrorCode::ProtocolError, error)
}

pub(crate) async fn read_frame<SR, const IS_HEADER_BLOCK: bool>(
  max_frame_len: u32,
  nrb: &mut BufStreamReader,
  stream_reader: &mut SR,
) -> crate::Result<Option<FrameInit>>
where
  SR: StreamReader,
{
  for _ in 0.._max_frames_mismatches!() {
    let Some(array) = nrb.read_header::<_, 9>(stream_reader).await? else {
      return Ok(None);
    };
    let (fi_opt, data_len) = FrameInit::from_array(array);
    if data_len > max_frame_len {
      return Err(crate::Error::Http2ErrorGoAway(
        Http2ErrorCode::FrameSizeError,
        Http2Error::LargeArbitraryFrameLen { received: data_len },
      ));
    }
    let data_len_usize = *Usize::from_u32(data_len);
    let Some(fi) = fi_opt else {
      if IS_HEADER_BLOCK {
        return Err(protocol_err(Http2Error::UnexpectedContinuationFrame));
      }
      if data_len > 32 {
        return Err(protocol_err(Http2Error::LargeIgnorableFrameLen));
      }
      nrb.read_payload(data_len_usize, stream_reader).await?;
      continue;
    };
    _trace!("Received frame: {fi:?}");
    nrb.read_payload(data_len_usize, stream_reader).await?;
    return Ok(Some(fi));
  }
  Err(protocol_err(Http2Error::VeryLargeAmountOfFrameMismatches))
}

pub(crate) async fn read_header_and_continuations<
  H,
  SR,
  const IS_CLIENT: bool,
  const IS_TRAILER: bool,
>(
  fi: FrameInit,
  hp: &mut HttpRecvParams,
  hpack_dec: &mut HpackDecoder,
  msg_buffer: &mut MsgBufferString,
  nrb: &mut BufStreamReader,
  stream_reader: &mut SR,
  mut headers_cb: impl FnMut(&HeadersFrame<'_>) -> crate::Result<H>,
) -> crate::Result<(Option<usize>, bool, H)>
where
  SR: StreamReader,
{
  if IS_TRAILER && !fi.cf.has_eos() {
    return Err(protocol_err(Http2Error::MissingEOSInTrailer));
  }

  let rrb_body_start = if IS_TRAILER {
    msg_buffer.body.len()
  } else {
    msg_buffer.clear();
    0
  };

  if fi.cf.has_eoh() {
    let (content_length, hf) = HeadersFrame::read::<IS_CLIENT, IS_TRAILER>(
      Some(nrb.current()),
      fi,
      hp,
      hpack_dec,
      (msg_buffer, rrb_body_start),
    )?;

    if hf.is_over_size() {
      return Err(crate::Error::Http2ErrorGoAway(
        Http2ErrorCode::FrameSizeError,
        Http2Error::VeryLargeHeadersLen,
      ));
    }
    return Ok((content_length, hf.has_eos(), headers_cb(&hf)?));
  }

  msg_buffer.body.extend_from_copyable_slice(nrb.current())?;

  'continuation_frames: {
    for _ in 0.._max_continuation_frames!() {
      let Some(frame_fi) = read_frame::<_, true>(hp.max_frame_len(), nrb, stream_reader).await?
      else {
        return Err(protocol_err(Http2Error::IncompleteHeader));
      };
      let has_diff_id = fi.stream_id != frame_fi.stream_id;
      let is_not_continuation = frame_fi.ty != FrameInitTy::Continuation;
      if has_diff_id || is_not_continuation {
        return Err(protocol_err(Http2Error::UnexpectedContinuationFrame));
      }
      msg_buffer.body.extend_from_copyable_slice(nrb.current())?;
      if frame_fi.cf.has_eoh() {
        break 'continuation_frames;
      }
    }
    return Err(protocol_err(Http2Error::VeryLargeAmountOfContinuationFrames));
  }

  let (content_length, hf) = HeadersFrame::read::<IS_CLIENT, IS_TRAILER>(
    None,
    fi,
    hp,
    hpack_dec,
    (msg_buffer, rrb_body_start),
  )?;
  if IS_TRAILER {
    msg_buffer.body.truncate(rrb_body_start);
  } else {
    msg_buffer.clear();
  }
  if hf.is_over_size() {
    return Err(crate::Error::Http2ErrorGoAway(
      Http2ErrorCode::FrameSizeError,
      Http2Error::VeryLargeHeadersLen,
    ));
  }
  Ok((content_length, hf.has_eos(), headers_cb(&hf)?))
}

pub(crate) async fn send_reset_stream<SW, TM, const IS_CLIENT: bool>(
  error_code: Http2ErrorCode,
  inner: &Http2Inner<SW, TM, IS_CLIENT>,
  stream_id: U31,
) -> bool
where
  SW: StreamWriter,
  TM: TlsMode,
{
  let rsf = ResetStreamFrame::new(error_code, stream_id);
  let mut has_stored = false;
  let _rslt = inner.wd.lock().await.write_all(&rsf.bytes()).await;
  let mut hd_guard = inner.hd.lock().await;
  if let Some(elem) = hd_guard.parts_mut().hb.scrps.get_mut(&stream_id) {
    has_stored = true;
    elem.is_stream_open = false;
    elem.stream_state = StreamState::Closed;
    elem.waker.wake_by_ref();
  }
  if let Some(elem) = hd_guard.parts_mut().hb.sorps.get_mut(&stream_id) {
    has_stored = true;
    elem.is_stream_open = false;
    elem.stream_state = StreamState::Closed;
    elem.waker.wake_by_ref();
  }
  has_stored
}

pub(crate) const fn server_header_stream_state(has_eos: bool) -> StreamState {
  if has_eos { StreamState::HalfClosedRemote } else { StreamState::Open }
}

pub(crate) fn status_recv<EOS, ONG>(
  is_conn_open: &AtomicU8,
  sorp: &mut StreamOverallRecvParams,
  eos_cb: impl FnOnce(&mut StreamOverallRecvParams) -> crate::Result<EOS>,
) -> crate::Result<Option<Http2RecvStatus<EOS, ONG>>> {
  if connection_state(is_conn_open).is_closed() {
    return Ok(Some(Http2RecvStatus::ClosedConnection));
  }
  if !sorp.is_stream_open {
    return Ok(Some(Http2RecvStatus::ClosedStream(eos_cb(sorp)?)));
  }
  if sorp.stream_state.recv_eos() {
    return Ok(Some(Http2RecvStatus::Eos(eos_cb(sorp)?)));
  }
  Ok(None)
}

pub(crate) fn status_send<const IS_CLIENT: bool>(
  is_conn_open: &AtomicU8,
  sorp: &StreamOverallRecvParams,
) -> Option<Http2SendStatus> {
  if connection_state(is_conn_open).is_closed() {
    return Some(Http2SendStatus::ClosedConnection);
  }
  if !sorp.is_stream_open {
    return Some(Http2SendStatus::ClosedStream);
  }
  if !sorp.stream_state.can_send::<IS_CLIENT>() {
    return Some(Http2SendStatus::InvalidState);
  }
  None
}

pub(crate) fn trim_frame_pad(cf: CommonFlags, data: &mut &[u8]) -> crate::Result<Option<u8>> {
  let mut pad_len = None;
  if cf.has_pad() {
    let [local_pad_len, rest @ ..] = data else {
      return Err(protocol_err(Http2Error::InvalidFramePad));
    };
    let idx_opt = rest.len().checked_sub(usize::from(*local_pad_len));
    let Some(local_data) = idx_opt.and_then(|idx| rest.get(..idx)) else {
      return Err(protocol_err(Http2Error::InvalidFramePad));
    };
    *data = local_data;
    pad_len = Some(*local_pad_len);
  }
  Ok(pad_len)
}

pub(crate) async fn write_array<SW, TM, const N: usize, const IS_CLIENT: bool>(
  array: [&[u8]; N],
  stream_writer: &mut TlsStreamWriter<SW, TM, IS_CLIENT>,
) -> crate::Result<()>
where
  SW: StreamWriter,
  TM: TlsMode,
{
  _trace!("Sending frame(s): {:?}", {
    let process = |elem: &mut Option<_>, frame: &[u8]| {
      let [b0, b1, b2, b3, b4, b5, b6, b7, b8, rest @ ..] = frame else {
        return;
      };
      if rest.len() > 36 {
        return;
      }
      let (Some(fi), _) = FrameInit::from_array([*b0, *b1, *b2, *b3, *b4, *b5, *b6, *b7, *b8])
      else {
        return;
      };
      *elem = Some(fi);
    };
    let mut rslt = [None; N];
    let mut iter = rslt.iter_mut().zip(array.iter());
    if let Some((elem, frame)) = iter.next()
      && frame != &crate::http2::PREFACE
    {
      process(elem, frame);
    }
    for (elem, frame) in iter {
      process(elem, frame);
    }
    rslt
  });
  stream_writer.write_all_vectored(&array).await?;
  Ok(())
}
