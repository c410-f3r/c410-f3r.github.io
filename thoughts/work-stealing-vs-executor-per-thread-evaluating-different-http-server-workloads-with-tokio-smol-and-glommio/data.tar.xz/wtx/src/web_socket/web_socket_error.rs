/// WebSocket Error
#[derive(Clone, Copy, Debug)]
pub enum WebSocketError {
  /// Peer closed the connection with or without a graceful stop
  ClosedConnection,
  /// User manually closed the handshake process midway.
  ClosedHandshake,
  /// HTTP headers must be unique.
  DuplicatedHeader,
  /// Received close frame has invalid parameters.
  InvalidCloseFrame,
  /// It was not possible to create a close frame with the given parameters.
  InvalidCloseFrameParams,
  /// Control frames can not exceed 125 bytes.
  InvalidControlFrame,
  /// Received an invalid header compression parameter.
  InvalidCompressionHeaderParameter,
  /// The client sent an invalid mask bit.
  InvalidMaskBit,
  /// Server received a frame without a mask.
  MissingFrameMask,
  /// Handshake response should return a 101 code.
  MissingSwitchingProtocols {
    /// The actual response code received
    found: Option<u16>,
  },
  /// Received control frame wasn't supposed to be fragmented.
  UnexpectedFragmentedControlFrame,
  /// For example, the first frame of a message is a continuation.
  UnexpectedFrame,
  /// Control frames have a maximum allowed size.
  VeryLargeControlFrame,
  /// Frame payload exceeds the defined threshold.
  VeryLargePayload,
}
