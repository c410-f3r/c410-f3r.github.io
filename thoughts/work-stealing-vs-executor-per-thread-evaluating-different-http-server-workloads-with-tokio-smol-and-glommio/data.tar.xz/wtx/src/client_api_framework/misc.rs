//! Utility functions and structures

mod from_bytes;
mod pair;
mod request_counter;
mod request_limit;

use crate::{
  client_api_framework::{
    Api,
    network::transport::Transport,
    pkg::{Package, PkgsAux},
  },
  codec::{Encode as _, EncodeWrapper},
  misc::from_utf8_basic,
};
pub use from_bytes::FromBytes;
pub use pair::{Pair, PairMut};
pub use request_counter::RequestCounter;
pub use request_limit::RequestLimit;

pub(crate) async fn manage_after_sending_bytes<A, DRSR, TP>(
  pkgs_aux: &mut PkgsAux<A, DRSR, TP>,
) -> Result<(), A::Error>
where
  A: Api,
{
  pkgs_aux.api.after_sending().await?;
  Ok(())
}

pub(crate) async fn manage_after_sending_pkg<A, DRSR, P, T, TP>(
  pkg: &mut P,
  pkgs_aux: &mut PkgsAux<A, DRSR, TP>,
  trans: &mut T,
) -> Result<(), A::Error>
where
  A: Api,
  P: Package<A, DRSR, T, TP>,
  T: Transport<TP>,
{
  pkgs_aux.api.after_sending().await?;
  pkg
    .after_sending(
      (&mut pkgs_aux.api, &mut pkgs_aux.bytes_buffer, &mut pkgs_aux.drsr),
      (trans, &mut pkgs_aux.tp),
    )
    .await?;
  Ok(())
}

pub(crate) async fn manage_before_sending_bytes<A, DRSR, TP>(
  pkgs_aux: &mut PkgsAux<A, DRSR, TP>,
) -> Result<(), A::Error>
where
  A: Api,
{
  pkgs_aux.api.before_sending().await?;
  Ok(())
}

pub(crate) async fn manage_before_sending_pkg<A, DRSR, P, T, TP>(
  pkg: &mut P,
  pkgs_aux: &mut PkgsAux<A, DRSR, TP>,
  trans: &mut T,
) -> Result<(), A::Error>
where
  A: Api,
  P: Package<A, DRSR, T, TP>,
  T: Transport<TP>,
{
  pkgs_aux.api.before_sending().await?;
  pkg
    .before_sending(
      (&mut pkgs_aux.api, &mut pkgs_aux.bytes_buffer, &mut pkgs_aux.drsr),
      (trans, &mut pkgs_aux.tp),
    )
    .await?;
  if pkgs_aux.encode_data {
    pkg
      .ext_req_content_mut()
      .encode(&mut EncodeWrapper::new(&mut pkgs_aux.bytes_buffer, &mut pkgs_aux.drsr))?;
  }
  Ok(())
}

#[cfg(feature = "http2")]
pub(crate) fn log_http_req<T, TP>(
  _bytes: &[u8],
  _log_data: bool,
  _method: crate::http::Method,
  _trans: &T,
  _uri: &crate::net::UriString,
) where
  T: Transport<TP>,
{
  let _body = if _log_data { from_utf8_basic(_bytes).ok() } else { None };
  _debug!(
    body = debug(_body),
    method = %_method,
    trans_ty = display(_trans.ty()),
    uri = display(_uri.origin()),
    "Request"
  );
}

pub(crate) fn log_req<T, TP>(_bytes: &[u8], _log_data: bool, _trans: &T)
where
  T: Transport<TP>,
{
  let _body = if _log_data { from_utf8_basic(_bytes).ok() } else { None };
  _debug!(body = debug(_body), trans_ty = display(_trans.ty()), "Request");
}
