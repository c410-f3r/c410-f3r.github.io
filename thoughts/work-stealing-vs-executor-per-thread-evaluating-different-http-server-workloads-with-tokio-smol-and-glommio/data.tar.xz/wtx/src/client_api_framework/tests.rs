use crate::collections::Vector;

#[allow(unreachable_pub, reason = "tests")]
#[test]
fn compiles() {
  create_packages_aux_wrapper!();
  let _pkg = PkgsAux::from_minimum((), (), ());
  let _pkg = PkgsAux::new((), 0, Vector::new(), (), false, false, ());
}
