use crate::{
  client_api_framework::{
    Api,
    network::{
      TransportGroup, WsParams,
      transport::{ReceivingTransport, Transport, log_generic_res},
    },
    pkg::PkgsAux,
  },
  misc::LeaseMut,
  net::StreamReader,
  tls::TlsMode,
  web_socket::{
    WebSocketPayloadOrigin, WebSocketReaderOwned, web_socket_compression::NegotiatedWsCompression,
  },
};

impl<NC, SR, TM, TP> ReceivingTransport<TP> for WebSocketReaderOwned<NC, SR, TM, true>
where
  NC: NegotiatedWsCompression,
  SR: StreamReader,
  TM: TlsMode,
  TP: LeaseMut<WsParams>,
{
  #[inline]
  async fn recv<A, DRSR>(
    &mut self,
    pkgs_aux: &mut PkgsAux<A, DRSR, TP>,
    _: Self::ReqId,
  ) -> Result<(), A::Error>
  where
    A: Api,
  {
    pkgs_aux.bytes_buffer.clear();
    let _frame =
      self.read_frame(&mut pkgs_aux.bytes_buffer, WebSocketPayloadOrigin::Consistent).await?;
    log_generic_res(&pkgs_aux.bytes_buffer, pkgs_aux.log_data, TransportGroup::WebSocket);
    Ok(())
  }
}

impl<NC, SR, TM, TP> Transport<TP> for WebSocketReaderOwned<NC, SR, TM, true>
where
  NC: NegotiatedWsCompression,
  SR: StreamReader,
{
  const GROUP: TransportGroup = TransportGroup::WebSocket;
  type Inner = Self;
  type ReqId = ();
}
