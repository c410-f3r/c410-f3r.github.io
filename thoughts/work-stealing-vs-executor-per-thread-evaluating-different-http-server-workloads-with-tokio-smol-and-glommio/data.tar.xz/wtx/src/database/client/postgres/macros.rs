macro_rules! impl_primitive {
  ($instance:expr, [$($elem:ident),+], $pg_ty:expr, $ty0:ident $(, $ty1:ident)?) => {
    impl<E> Decode<'_, Postgres<E>> for $ty0
    where
      E: From<crate::Error>,
    {
      #[inline]
      fn decode(dw: &mut PostgresDecodeWrapper<'_, '_>) -> Result<Self, E> {
        if let &[$($elem,)+] = dw.bytes() {
          let array = [$($elem),+];
          #[allow(unused_assignments, unused_mut, reason = "depends on macro")]
          let mut num = <Self>::from_be_bytes(array);
          $({
            let signed = $ty1::from_be_bytes(array);
            num = signed.try_into().map_err(crate::Error::from)?;
          })?
          return Ok(num);
        }
        Err(E::from(DatabaseError::UnexpectedBufferSize {
          expected: Usize::from(size_of::<$ty0>()).into_u64().try_into().unwrap_or(u32::MAX),
          received: Usize::from(dw.bytes().len()).into_u64().try_into().unwrap_or(u32::MAX)
        }.into()))
      }
    }

    impl<E> Encode<Postgres<E>> for $ty0
    where
      E: From<crate::Error>,
    {
      #[inline]
      fn encode(&self, ew: &mut PostgresEncodeWrapper<'_>) -> Result<(), E> {
        ew.buffer().extend_from_copyable_slice(&self.to_be_bytes())?;
        Ok(())
      }
    }

    impl<E> Typed<Postgres<E>> for $ty0
    where
      E: From<crate::Error>
    {
      #[inline]
      fn runtime_ty(&self) -> Option<Ty> {
        <Self as Typed<Postgres<E>>>::static_ty()
      }

      #[inline]
      fn static_ty() -> Option<Ty> {
        Some($pg_ty)
      }
    }

    test!($ty0, $ty0, $instance);
  }
}

macro_rules! kani {
  ($name:ident, $ty:ty) => {
    #[cfg(kani)]
    #[kani::proof]
    fn $name(instance: $ty) {
      let mut vec = &mut crate::misc::FilledBuffer::_new();
      {
        let mut sw = crate::misc::FilledBufferWriter::new(0, &mut vec);
        let mut ew = EncodeValue::new(&mut sw);
        Encode::<Postgres<crate::Error>>::encode(&instance, &mut ew).unwrap();
        let decoded: $ty = Decode::<Postgres<crate::Error>>::decode(&DecodeValue::new(
          ew.sw()._curr_bytes(),
          crate::database::client::postgres::Ty::Any,
        ))
        .unwrap();
        assert_eq!(instance, decoded);
      }
      vec._clear();
    }
  };
}

macro_rules! test {
  ($name:ident, $ty:ty, $instance:expr) => {
    #[cfg(test)]
    #[test]
    fn $name() {
      let mut vec = crate::collections::Vector::new();
      let mut suffix_pusher = vec.suffix_pusher();
      let mut ew = PostgresEncodeWrapper::new(suffix_pusher.inner_mut());
      let instance: $ty = $instance;
      Encode::<Postgres<crate::Error>>::encode(&instance, &mut ew).unwrap();
      let decoded: $ty = Decode::<Postgres<crate::Error>>::decode(&mut PostgresDecodeWrapper::new(
        suffix_pusher.curr(),
        "",
        crate::database::client::postgres::Ty::Any,
      ))
      .unwrap();
      assert_eq!(instance, decoded);
    }
  };
}
