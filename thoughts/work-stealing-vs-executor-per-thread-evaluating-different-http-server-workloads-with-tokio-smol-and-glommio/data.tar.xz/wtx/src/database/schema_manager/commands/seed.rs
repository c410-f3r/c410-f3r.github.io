use crate::{
  codec::CodecController,
  database::{db_client::DbClient, schema_manager::Commands},
  misc::Lease,
};
use alloc::string::String;
#[cfg(feature = "std")]
use std::{fs::read_to_string, path::Path};

impl<E> Commands<E>
where
  E: DbClient,
{
  /// Executes an arbitrary stream of SQL commands
  ///
  /// It is up to be caller to actually seed the database with data.
  #[inline]
  pub async fn seed<S>(
    &mut self,
    seeds: impl IntoIterator<Item = S>,
  ) -> Result<(), <E::Database as CodecController>::Error>
  where
    S: Lease<str>,
  {
    let mut buffer_cmd = String::new();
    for elem in seeds {
      buffer_cmd.push_str(elem.lease());
    }
    self
      .executor
      .transaction(async |this| {
        this.execute_ignored(buffer_cmd.as_str()).await?;
        Ok(((), this))
      })
      .await?;
    Ok(())
  }

  /// Applies `Commands::seed` from a set of files located inside a given `dir`.
  #[cfg(feature = "std")]
  #[inline]
  pub async fn seed_from_dir(
    &mut self,
    dir: &Path,
  ) -> Result<(), <E::Database as CodecController>::Error> {
    let iter = crate::database::schema_manager::misc::files(dir)?.filter_map(|el_rslt| {
      let el = el_rslt.ok()?;
      read_to_string(el.path()).ok()
    });
    self.seed(iter).await
  }
}
