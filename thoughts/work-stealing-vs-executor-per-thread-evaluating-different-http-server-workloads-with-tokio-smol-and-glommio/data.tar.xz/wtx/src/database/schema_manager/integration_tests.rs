mod backend;
mod db;
mod generic;
mod schema;

use crate::{
  codec::CodecController,
  collections::Vector,
  database::{
    Database, DbClient, Identifier,
    schema_manager::{
      Commands, DbMigration, MigrationStatus, SchemaManagement, UserMigrationGroup,
      doc_tests::{user_migration, user_migration_group},
    },
  },
  executor::StdRuntime,
};
use alloc::string::String;
use core::fmt::{Debug, Write};

macro_rules! create_integration_test {
  ($executor:expr, $buffer:expr, $aux:expr, $($fun:path),*) => {{
    $({
      let mut commands = crate::database::schema_manager::Commands::with_executor($executor);
      commands.clear().await.unwrap();
      $fun($buffer, &mut commands, $aux).await;
    })*
  }};
}

macro_rules! create_integration_tests {
  (
    $fn_name:ident,
    postgres: $($postgres:path),*;
  ) => {
    pub(crate) async fn $fn_name() {
      let mut _buffer_cmd = String::new();
      let mut _buffer_db_migrations = Vector::<DbMigration>::new();
      let mut _buffer_idents = Vector::<Identifier>::new();
      let mut _buffer_status = Vector::<MigrationStatus>::new();

      #[cfg(feature = "postgres")]
      create_integration_test!(
        {
          use crate::rng::CryptoSeedableRng;
          let uri = crate::net::UriRef::new(crate::tests::_vars().database_uri_postgres.as_str());
          let config = crate::database::client::postgres::Config::from_uri(&uri).unwrap();
          let mut tls_connector = crate::tls::TlsConnectorBuilder::new(
            crate::executor::StdExecutor::default(),
            &uri
          )
          .build(
            crate::tls::TlsConfig::plaintext(),
            crate::rng::ChaCha20::from_std_random().unwrap(),
          )
          .await
          .unwrap();
          let client_buffer = crate::database::client::postgres::ClientBuffer::new(usize::MAX, tls_connector.rng_mut());
          crate::database::client::postgres::PostgresClient::<crate::Error, _, _>::connect(
            client_buffer,
            &config,
            tls_connector
          )
          .await
          .unwrap()
        },
        (&mut _buffer_cmd, &mut _buffer_db_migrations, &mut _buffer_idents, &mut _buffer_status),
        _pg_schema(),
        $($postgres),*
      );
    }
  };
}

macro_rules! create_all_integration_tests {
  (
    postgres: $($postgres:path),*;

    generic: $($fun:path),*;

    with_schema: $($with_schema:path),*;
    without_schema: $($without_schema:path),*;
  ) => {
    create_integration_tests!(
      integration_tests_db,
      postgres: $($postgres),*;
    );

    create_integration_tests!(
      integration_tests_generic,
      postgres: $($fun),*;
    );

    create_integration_tests!(
      integration_tests_schema,
      postgres: $($with_schema),*;
    );

    #[test]
    fn integration_tests() {
      StdRuntime::new()
        .block_on(async {
          integration_tests_db().await;
          integration_tests_generic().await;
          integration_tests_schema().await;
        });
    }
  };
}

create_all_integration_tests!(
  // Database

  postgres:
    db::postgres::clean_drops_all_objs;

  // Generic

  generic:
    generic::all_tables_returns_the_number_of_tables_of_the_default_schema,
    generic::rollback_works;

  // Schema

  with_schema:
    schema::with_schema::all_tables_returns_the_number_of_tables_of_wtx_schema,
    schema::with_schema::migrate_works;

  without_schema:
    schema::without_schema::_migrate_works;
);

#[derive(Clone, Copy)]
pub(crate) struct AuxTestParams {
  pub(crate) default_schema: &'static str,
  pub(crate) schema_regulator: usize,
  pub(crate) wtx_schema: &'static str,
}

pub(crate) async fn create_foo_table<E>(
  buffer_cmd: &mut String,
  c: &mut Commands<E>,
  schema_prefix: &str,
) where
  E: SchemaManagement,
  <<E as DbClient>::Database as CodecController>::Error: Debug,
{
  buffer_cmd.write_fmt(format_args!("CREATE TABLE {schema_prefix}foo(id INT)")).unwrap();
  c._executor_mut().execute_ignored(buffer_cmd.as_str()).await.unwrap();
  buffer_cmd.clear();
}

pub(crate) fn _generic_schema() -> AuxTestParams {
  AuxTestParams { default_schema: "", wtx_schema: "", schema_regulator: 2 }
}

pub(crate) async fn _migrate_doc_test<DB, E>(
  c: &mut Commands<E>,
) -> UserMigrationGroup<&'static str>
where
  DB: Database<Error = crate::Error>,
  E: SchemaManagement<Database = DB>,
{
  let mg = user_migration_group();
  let _s = c.migrate(&mg, [&user_migration()]).await.unwrap();
  mg
}

pub(crate) fn _pg_schema() -> AuxTestParams {
  AuxTestParams { default_schema: "public", wtx_schema: "_wtx", schema_regulator: 0 }
}
