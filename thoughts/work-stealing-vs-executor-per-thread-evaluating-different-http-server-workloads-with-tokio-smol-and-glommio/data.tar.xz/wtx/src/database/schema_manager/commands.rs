#[cfg(feature = "schema-manager-dev")]
mod clear;
mod migrate;
#[cfg(all(feature = "schema-manager-dev", feature = "std"))]
mod multi;
mod rollback;
#[cfg(feature = "schema-manager-dev")]
mod seed;
mod validate;

use crate::{
  codec::CodecController,
  collections::Vector,
  database::{
    Database, DatabaseTy, Identifier,
    db_client::DbClient,
    schema_manager::{DEFAULT_BATCH_SIZE, SchemaManagement, UserMigration},
  },
  misc::Lease,
};
use alloc::string::String;

/// SQL commands facade
#[derive(Debug)]
pub struct Commands<E> {
  batch_size: usize,
  executor: E,
}

impl<E> Commands<E>
where
  E: DbClient,
{
  /// Creates a new instance from a given Backend and batch size.
  #[inline]
  pub const fn new(batch_size: usize, executor: E) -> Self {
    Self { batch_size, executor }
  }

  /// Creates a new instance from a given Backend.
  ///
  /// Batch size will default to 128.
  #[inline]
  pub const fn with_executor(database: E) -> Self {
    Self { batch_size: DEFAULT_BATCH_SIZE, executor: database }
  }

  /// Batch size
  #[inline]
  pub const fn batch_size(&self) -> usize {
    self.batch_size
  }

  /// Allows the access of the internal executor
  pub(crate) fn _executor_mut(&mut self) -> &mut E {
    &mut self.executor
  }

  fn filter_by_db<'migration, DBS, I, S>(
    migrations: I,
  ) -> impl Clone + Iterator<Item = &'migration UserMigration<DBS, S>>
  where
    DBS: Lease<[DatabaseTy]> + 'migration,
    I: Clone + Iterator<Item = &'migration UserMigration<DBS, S>>,
    S: Lease<str> + 'migration,
  {
    migrations.filter(move |el| {
      if el.dbs().is_empty() { true } else { el.dbs().contains(&<E::Database as Database>::TY) }
    })
  }
}

impl<E> Commands<E>
where
  E: SchemaManagement,
{
  /// Retrieves all inserted elements.
  #[inline]
  pub async fn all_elements(
    &mut self,
  ) -> Result<Vector<Identifier>, <E::Database as CodecController>::Error> {
    let mut buffer = Vector::new();
    self.executor.all_elements((&mut String::new(), &mut buffer)).await?;
    Ok(buffer)
  }
}
