macro_rules! generic_data_format_doc {
  ($ty:literal) => {
    concat!("Wrapper used in every generic ", $ty, " to manage different internal implementations.")
  };
}

macro_rules! _impl_dec {
  (
    $struct:ident<$(($($ty:tt)*) $(: $bound:path)?),*>,
    $drsr:ty,
    |$aux:ident, $dw:ident| $impl:block
  ) => {
    impl<'de, EA, $($($ty)* $(: $bound)?,)*> crate::codec::Decode<'de, crate::codec::GenericCodec<&mut $drsr, EA>> for $struct<$($($ty)*,)*> {
      #[inline]
      fn decode($dw: &mut crate::codec::DecodeWrapper<'de, &mut $drsr>) -> crate::Result<Self> {
        $impl
      }
    }
  }
}

macro_rules! _impl_dec_seq {
  (
    $struct:ident<$($ty:ident $(: $bound:path)?),*>,
    $drsr:ty,
    |$aux:ident, $buffer:ident, $dw:ident| $impl:block
  ) => {
    impl<'de, EA, $($ty: $($bound)?,)*> crate::codec::DecodeSeq<'de, crate::codec::GenericCodec<&mut $drsr, EA>> for $struct<$($ty,)*> {
      #[inline]
      fn decode_seq(
        $buffer: &mut crate::collections::Vector<Self>,
        $dw: &mut crate::codec::DecodeWrapper<'de, &mut $drsr>,
      ) -> crate::Result<()> {
        $impl
      }
    }
  }
}

macro_rules! _impl_enc {
  (
    $struct:ident<$($ty:ident $(: $bound:path)?),*>,
    $drsr:ty,
    |$this:ident, $aux:ident, $ew:ident| $impl:block
  ) => {
    impl<DA, $($ty: $($bound)?,)*> crate::codec::Encode<crate::codec::GenericCodec<DA, &mut $drsr>> for $struct<$($ty,)*> {
      #[inline]
      fn encode(
        &self,
        $ew: &mut crate::codec::EncodeWrapper<'_, &mut $drsr>
      ) -> crate::Result<()> {
        if size_of::<Self>() == 0 {
          return Ok(());
        }
        let $this = self;
        $impl
        Ok(())
      }
    }
  }
}

macro_rules! _impl_se_collections {
  (
    ($drsr:ty, $bound:path),
    $( array: |$array_self:ident, $array_bytes:ident, $array_drsr:ident| $array_block:block )?
    $( arrayvector: |$arrayvector_self:ident, $arrayvector_bytes:ident, $arrayvector_drsr:ident| $arrayvector_block:block )?
    slice_ref: |$slice_ref_self:ident, $slice_ref_bytes:ident, $slice_ref_drsr:ident| $slice_ref_block:block
    vec: |$vec_self:ident, $vec_bytes:ident, $vec_drsr:ident| $vec_block:block
  ) => {
    $(
      impl<DA, T, const N: usize> crate::codec::Encode<crate::codec::GenericCodec<DA, &mut $drsr>> for [T; N]
      where
        T: $bound,
      {
        #[inline]
        fn encode(&self, ew: &mut crate::codec::EncodeWrapper<'_, &mut $drsr>) -> crate::Result<()> {
          let $array_self = self;
          let $array_bytes = &mut *ew.buffer;
          $array_block;
          Ok(())
        }
      }
    )?

    $(
      impl<DA, L, T, const N: usize> crate::codec::Encode<crate::codec::GenericCodec<DA, &mut $drsr>> for crate::collections::ArrayVector<L, T, N>
      where
        L: crate::collections::LinearStorageLen,
        T: $bound,
      {
        #[inline]
        fn encode(&self, ew: &mut crate::codec::EncodeWrapper<'_, &mut $drsr>) -> crate::Result<()> {
          let $arrayvector_self = self;
          let $arrayvector_bytes = &mut *ew.buffer;
          $arrayvector_block;
          Ok(())
        }
      }
    )?

    impl<DA, T> crate::codec::Encode<crate::codec::GenericCodec<DA, &mut $drsr>> for &'_ [T]
    where
      T: $bound,
    {
      #[inline]
      fn encode(&self, ew: &mut crate::codec::EncodeWrapper<'_, &mut $drsr>) -> crate::Result<()> {
        let $slice_ref_self = self;
        let $slice_ref_bytes = &mut *ew.buffer;
        $slice_ref_block;
        Ok(())
      }
    }

    impl<DA, T> crate::codec::Encode<crate::codec::GenericCodec<DA, &mut $drsr>> for crate::collections::Vector<T>
    where
      T: $bound,
    {
      #[inline]
      fn encode(&self, ew: &mut crate::codec::EncodeWrapper<'_, &mut $drsr>) -> crate::Result<()> {
        let $vec_self = self;
        let $vec_bytes = &mut *ew.buffer;
        $vec_block;
        Ok(())
      }
    }
  };
}
